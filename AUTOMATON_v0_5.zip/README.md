# AUTOMATON v0.5 — Scheduled Online Opportunity Hunter

This package moves the hunt from your phone to a scheduled cloud workflow using GitHub Actions. It fetches two public job feeds, scores listings with transparent keyword rules, and produces a Markdown report and JSON data file.

## What it can do
- Run manually or on a twice-daily schedule after setup.
- Search public feeds from Remote OK and Arbeitnow.
- Rank likely fit and flag suspicious wording.
- Store the report as a downloadable workflow artifact for 7 days.
- No paid API keys are used by this code.

## Android-only setup (GitHub website)
1. Sign in to GitHub in your phone browser or app and create a repository named `automaton-opportunity-hunter`.
2. To keep the code and workflow free to run without paid API use, make it a **public repository**. The code and workflow logs are public, so do not add personal information, passwords, tokens, or private customer data.
3. Upload `automaton_v0_5.py` to the repository root.
4. Create the path `.github/workflows/hunt.yml` and paste the contents of the included `hunt.yml`.
5. Open the repository's **Actions** tab. If GitHub asks you to enable workflows, enable them.
6. Select **AUTOMATON Scheduled Opportunity Hunt** → **Run workflow** to test it.
7. After a successful run, open the run and download the `automaton-opportunity-report` artifact. Scheduled runs are configured twice daily; GitHub may delay scheduled jobs, and the workflow must remain enabled.

## Files
- `automaton_v0_5.py`: search, scoring, and report generator.
- `.github/workflows/hunt.yml`: scheduled runner definition.
- `README.md`: setup and limitations.

## Important limits
- It currently searches two public job feeds, not the entire internet.
- It does not apply, message recruiters, create accounts, accept payments, or guarantee earnings.
- The score is a heuristic, not a hiring probability or legitimacy check.
- A listing can be stale, and "remote" may exclude applicants from Kenya; verify the original listing.
- Free cloud schedules have provider rules and may be delayed. No always-on service is guaranteed.
- Report artifacts expire after seven days in this setup, so download reports you want to keep.
- Network/data costs may apply on your phone.
- Never pay a recruiter, share OTPs/passwords/PINs, receive and forward money, or buy equipment from a supposed employer.

## Sources
- Remote OK: https://remoteok.com/
- Arbeitnow: https://www.arbeitnow.com/
